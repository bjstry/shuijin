<?php
define('PRJ','ShuiJin');
require '../Speek/Speek.php';
?>
